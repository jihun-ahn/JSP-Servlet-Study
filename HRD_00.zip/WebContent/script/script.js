/*
*
*/
function chk(){
	if(!document.form.custno.value){
		alert();
		document.form.custname.focus
		return false;	
	}else{
		return true;
	}
	
}